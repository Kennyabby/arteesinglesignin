var require = meteorInstall({"imports":{"api":{"links.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/api/links.js                                                             //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.export({
  AppsheetLink: () => AppsheetLink
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const AppsheetLink = new Mongo.Collection('AppsheetLink');

if (Meteor.isClient) {
  Meteor.subscribe('AppsheetLink');
}
//////////////////////////////////////////////////////////////////////////////////////

},"userLogin.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/api/userLogin.js                                                         //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.export({
  LoginDetails: () => LoginDetails
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const LoginDetails = new Mongo.Collection('LoginDetails');
//////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// server/main.js                                                                   //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let AppsheetLink;
module.link("/imports/api/links", {
  AppsheetLink(v) {
    AppsheetLink = v;
  }

}, 1);
let LoginDetails;
module.link("/imports/api/userLogin", {
  LoginDetails(v) {
    LoginDetails = v;
  }

}, 2);

// import AWS from 'aws-sdk';
// const S3_BUCKET ='help-desk-bucket';
// const REGION ='eu-west-1';
// AWS.config.update({
//     apiVersion: "2010-12-01",
//     accessKeyId: process.env.ACCESS_KEY_ID,
//     secretAccessKey: process.env.SECRET_ACCESS_KEY,
//     region: REGION,
//     endpoint: "http://54.247.57.9:3000",
// })
// const myBucket = new AWS.S3({
//     params: { Bucket: S3_BUCKET},
//     region: REGION,
// })
if (Meteor.isServer) {
  // console.log(sessionStorage)
  Meteor.startup(function () {
    // console.log(LoginDetails.find().fetch());
    //  AppsheetLink.insert({
    //   title:"Artee Visitor Regulator",
    //   logo:"artee_visitor_regulator.png",
    //   url:"https://www.appsheet.com/start/e20ae8b0-dc92-40fd-b080-a8fbc767b0ea",
    //   createdAt:new Date()
    //  })
    //  AppsheetLink.insert({
    //   title:"Artee Ticketing 2021",
    //   logo:"artee_ticketing_2021.jpg",
    //   url:"https://www.appsheet.com/start/345a570c-710d-4a30-9d56-a6450994860b",
    //   createdAt:new Date()
    //  })
    //  AppsheetLink.insert({
    //   title:"Artee Vehicle Inspection",
    //   logo:"artee_vehicle_inspection.png",
    //   url:"https://www.appsheet.com/start/8f7ae2fa-acdb-42f0-afb3-cd2fe696c9a2",
    //   createdAt:new Date()
    //  })
    //  AppsheetLink.insert({
    //   title:"Barman Stock Take",
    //   url:"https://www.appsheet.com/start/e5a0150f-6668-4ee8-8e10-c0a4130a3e3e",
    //   createdAt:new Date()
    //  })
    // LoginDetails.insert({
    //   username:"arteegroup",
    //   password:"10artee01",
    //   status:"User",
    //   active:"off",
    //   page:"loginPage"
    //  })
    //  LoginDetails.insert({
    //   username:"arteeadmin",
    //   password:"admin114",
    //   status:"Admin",
    //   active:"off",
    //   page:"loginPage"
    //  })
    //  console.log(LoginDetails.find().fetch());
    //   Myvars = new Mongo.Collection("myvars");
    // LoginDetails.remove({});
    // AppsheetLink.remove({});
    // console.log(AppsheetLink.find().fetch());
    // console.log(process.env.ACCESS_KEY_ID);
    LoginDetails.allow({
      insert: function () {
        return true;
      },
      update: function () {
        return true;
      },
      remove: function () {
        return true;
      }
    });
    AppsheetLink.allow({
      insert: function () {
        return true;
      },
      update: function () {
        return true;
      },
      remove: function () {
        return true;
      }
    });
    Meteor.publish("LoginDetails", function () {
      return LoginDetails.find();
    });
    Meteor.publish("AppsheetLink", function () {
      return AppsheetLink.find();
    });
  });
}
//////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbGlua3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VzZXJMb2dpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQXBwc2hlZXRMaW5rIiwiTW9uZ28iLCJsaW5rIiwidiIsIkNvbGxlY3Rpb24iLCJNZXRlb3IiLCJpc0NsaWVudCIsInN1YnNjcmliZSIsIkxvZ2luRGV0YWlscyIsImlzU2VydmVyIiwic3RhcnR1cCIsImFsbG93IiwiaW5zZXJ0IiwidXBkYXRlIiwicmVtb3ZlIiwicHVibGlzaCIsImZpbmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFbEQsTUFBTUgsWUFBWSxHQUFHLElBQUlDLEtBQUssQ0FBQ0csVUFBVixDQUFxQixjQUFyQixDQUFyQjs7QUFFUCxJQUFHQyxNQUFNLENBQUNDLFFBQVYsRUFBb0I7QUFDaEJELFFBQU0sQ0FBQ0UsU0FBUCxDQUFpQixjQUFqQjtBQUVILEM7Ozs7Ozs7Ozs7O0FDUERULE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNTLGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlQLEtBQUo7QUFBVUgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFbEQsTUFBTUssWUFBWSxHQUFHLElBQUlQLEtBQUssQ0FBQ0csVUFBVixDQUFxQixjQUFyQixDQUFyQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUlDLE1BQUo7QUFBV1AsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRyxRQUFNLENBQUNGLENBQUQsRUFBRztBQUFDRSxVQUFNLEdBQUNGLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUgsWUFBSjtBQUFpQkYsTUFBTSxDQUFDSSxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ0YsY0FBWSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsZ0JBQVksR0FBQ0csQ0FBYjtBQUFlOztBQUFoQyxDQUFqQyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJSyxZQUFKO0FBQWlCVixNQUFNLENBQUNJLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDTSxjQUFZLENBQUNMLENBQUQsRUFBRztBQUFDSyxnQkFBWSxHQUFDTCxDQUFiO0FBQWU7O0FBQWhDLENBQXJDLEVBQXVFLENBQXZFOztBQUd4SztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsSUFBR0UsTUFBTSxDQUFDSSxRQUFWLEVBQW9CO0FBQ2xCO0FBQ0VKLFFBQU0sQ0FBQ0ssT0FBUCxDQUFlLFlBQVk7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Y7QUFDRTtBQUNBO0FBQ0E7QUFDQTtBQUNBRixnQkFBWSxDQUFDRyxLQUFiLENBQW1CO0FBQ2pCQyxZQUFNLEVBQUUsWUFBWTtBQUNsQixlQUFPLElBQVA7QUFDRCxPQUhnQjtBQUlqQkMsWUFBTSxFQUFFLFlBQVk7QUFDbEIsZUFBTyxJQUFQO0FBQ0QsT0FOZ0I7QUFPakJDLFlBQU0sRUFBRSxZQUFZO0FBQ2xCLGVBQU8sSUFBUDtBQUNEO0FBVGdCLEtBQW5CO0FBWUFkLGdCQUFZLENBQUNXLEtBQWIsQ0FBbUI7QUFDakJDLFlBQU0sRUFBRSxZQUFZO0FBQ2xCLGVBQU8sSUFBUDtBQUNELE9BSGdCO0FBSWpCQyxZQUFNLEVBQUUsWUFBWTtBQUNsQixlQUFPLElBQVA7QUFDRCxPQU5nQjtBQU9qQkMsWUFBTSxFQUFFLFlBQVk7QUFDbEIsZUFBTyxJQUFQO0FBQ0Q7QUFUZ0IsS0FBbkI7QUFZRlQsVUFBTSxDQUFDVSxPQUFQLENBQWUsY0FBZixFQUErQixZQUFVO0FBRXJDLGFBQU9QLFlBQVksQ0FBQ1EsSUFBYixFQUFQO0FBQ0gsS0FIRDtBQUlBWCxVQUFNLENBQUNVLE9BQVAsQ0FBZSxjQUFmLEVBQStCLFlBQVU7QUFFckMsYUFBT2YsWUFBWSxDQUFDZ0IsSUFBYixFQUFQO0FBQ0gsS0FIRDtBQUlDLEdBN0VEO0FBOEVILEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IEFwcHNoZWV0TGluayA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdBcHBzaGVldExpbmsnKTtcblxuaWYoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnQXBwc2hlZXRMaW5rJyk7XG4gICAgXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgTG9naW5EZXRhaWxzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ0xvZ2luRGV0YWlscycpO1xuXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFwcHNoZWV0TGluayB9IGZyb20gJy9pbXBvcnRzL2FwaS9saW5rcyc7XG5pbXBvcnQgeyBMb2dpbkRldGFpbHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdXNlckxvZ2luJztcbi8vIGltcG9ydCBBV1MgZnJvbSAnYXdzLXNkayc7XG4vLyBjb25zdCBTM19CVUNLRVQgPSdoZWxwLWRlc2stYnVja2V0Jztcbi8vIGNvbnN0IFJFR0lPTiA9J2V1LXdlc3QtMSc7XG5cbi8vIEFXUy5jb25maWcudXBkYXRlKHtcbi8vICAgICBhcGlWZXJzaW9uOiBcIjIwMTAtMTItMDFcIixcbi8vICAgICBhY2Nlc3NLZXlJZDogcHJvY2Vzcy5lbnYuQUNDRVNTX0tFWV9JRCxcbi8vICAgICBzZWNyZXRBY2Nlc3NLZXk6IHByb2Nlc3MuZW52LlNFQ1JFVF9BQ0NFU1NfS0VZLFxuLy8gICAgIHJlZ2lvbjogUkVHSU9OLFxuLy8gICAgIGVuZHBvaW50OiBcImh0dHA6Ly81NC4yNDcuNTcuOTozMDAwXCIsXG4vLyB9KVxuXG4vLyBjb25zdCBteUJ1Y2tldCA9IG5ldyBBV1MuUzMoe1xuLy8gICAgIHBhcmFtczogeyBCdWNrZXQ6IFMzX0JVQ0tFVH0sXG4vLyAgICAgcmVnaW9uOiBSRUdJT04sXG4vLyB9KVxuXG5pZihNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgLy8gY29uc29sZS5sb2coc2Vzc2lvblN0b3JhZ2UpXG4gICAgTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24gKCkge1xuICAgICAgLy8gY29uc29sZS5sb2coTG9naW5EZXRhaWxzLmZpbmQoKS5mZXRjaCgpKTtcbiAgICAgIC8vICBBcHBzaGVldExpbmsuaW5zZXJ0KHtcbiAgICAgIC8vICAgdGl0bGU6XCJBcnRlZSBWaXNpdG9yIFJlZ3VsYXRvclwiLFxuICAgICAgLy8gICBsb2dvOlwiYXJ0ZWVfdmlzaXRvcl9yZWd1bGF0b3IucG5nXCIsXG4gICAgICAvLyAgIHVybDpcImh0dHBzOi8vd3d3LmFwcHNoZWV0LmNvbS9zdGFydC9lMjBhZThiMC1kYzkyLTQwZmQtYjA4MC1hOGZiYzc2N2IwZWFcIixcbiAgICAgIC8vICAgY3JlYXRlZEF0Om5ldyBEYXRlKClcbiAgICAgIC8vICB9KVxuICAgICAgLy8gIEFwcHNoZWV0TGluay5pbnNlcnQoe1xuICAgICAgLy8gICB0aXRsZTpcIkFydGVlIFRpY2tldGluZyAyMDIxXCIsXG4gICAgICAvLyAgIGxvZ286XCJhcnRlZV90aWNrZXRpbmdfMjAyMS5qcGdcIixcbiAgICAgIC8vICAgdXJsOlwiaHR0cHM6Ly93d3cuYXBwc2hlZXQuY29tL3N0YXJ0LzM0NWE1NzBjLTcxMGQtNGEzMC05ZDU2LWE2NDUwOTk0ODYwYlwiLFxuICAgICAgLy8gICBjcmVhdGVkQXQ6bmV3IERhdGUoKVxuICAgICAgLy8gIH0pXG4gICAgICAvLyAgQXBwc2hlZXRMaW5rLmluc2VydCh7XG4gICAgICAvLyAgIHRpdGxlOlwiQXJ0ZWUgVmVoaWNsZSBJbnNwZWN0aW9uXCIsXG4gICAgICAvLyAgIGxvZ286XCJhcnRlZV92ZWhpY2xlX2luc3BlY3Rpb24ucG5nXCIsXG4gICAgICAvLyAgIHVybDpcImh0dHBzOi8vd3d3LmFwcHNoZWV0LmNvbS9zdGFydC84ZjdhZTJmYS1hY2RiLTQyZjAtYWZiMy1jZDJmZTY5NmM5YTJcIixcbiAgICAgIC8vICAgY3JlYXRlZEF0Om5ldyBEYXRlKClcbiAgICAgIC8vICB9KVxuICAgICAgLy8gIEFwcHNoZWV0TGluay5pbnNlcnQoe1xuICAgICAgLy8gICB0aXRsZTpcIkJhcm1hbiBTdG9jayBUYWtlXCIsXG4gICAgICAvLyAgIHVybDpcImh0dHBzOi8vd3d3LmFwcHNoZWV0LmNvbS9zdGFydC9lNWEwMTUwZi02NjY4LTRlZTgtOGUxMC1jMGE0MTMwYTNlM2VcIixcbiAgICAgIC8vICAgY3JlYXRlZEF0Om5ldyBEYXRlKClcbiAgICAgIC8vICB9KVxuICAgICAgLy8gTG9naW5EZXRhaWxzLmluc2VydCh7XG4gICAgICAvLyAgIHVzZXJuYW1lOlwiYXJ0ZWVncm91cFwiLFxuICAgICAgLy8gICBwYXNzd29yZDpcIjEwYXJ0ZWUwMVwiLFxuICAgICAgLy8gICBzdGF0dXM6XCJVc2VyXCIsXG4gICAgICAvLyAgIGFjdGl2ZTpcIm9mZlwiLFxuICAgICAgLy8gICBwYWdlOlwibG9naW5QYWdlXCJcbiAgICAgIC8vICB9KVxuICAgICAgLy8gIExvZ2luRGV0YWlscy5pbnNlcnQoe1xuICAgICAgLy8gICB1c2VybmFtZTpcImFydGVlYWRtaW5cIixcbiAgICAgIC8vICAgcGFzc3dvcmQ6XCJhZG1pbjExNFwiLFxuICAgICAgLy8gICBzdGF0dXM6XCJBZG1pblwiLFxuICAgICAgLy8gICBhY3RpdmU6XCJvZmZcIixcbiAgICAgIC8vICAgcGFnZTpcImxvZ2luUGFnZVwiXG4gICAgICAvLyAgfSlcbiAgICAgIC8vICBjb25zb2xlLmxvZyhMb2dpbkRldGFpbHMuZmluZCgpLmZldGNoKCkpO1xuICAgIC8vICAgTXl2YXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJteXZhcnNcIik7XG4gICAgICAvLyBMb2dpbkRldGFpbHMucmVtb3ZlKHt9KTtcbiAgICAgIC8vIEFwcHNoZWV0TGluay5yZW1vdmUoe30pO1xuICAgICAgLy8gY29uc29sZS5sb2coQXBwc2hlZXRMaW5rLmZpbmQoKS5mZXRjaCgpKTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKHByb2Nlc3MuZW52LkFDQ0VTU19LRVlfSUQpO1xuICAgICAgTG9naW5EZXRhaWxzLmFsbG93KHtcbiAgICAgICAgaW5zZXJ0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIHVwZGF0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICByZW1vdmU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIEFwcHNoZWV0TGluay5hbGxvdyh7XG4gICAgICAgIGluc2VydDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVtb3ZlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgTWV0ZW9yLnB1Ymxpc2goXCJMb2dpbkRldGFpbHNcIiwgZnVuY3Rpb24oKXtcblxuICAgICAgICByZXR1cm4gTG9naW5EZXRhaWxzLmZpbmQoKTtcbiAgICB9KTtcbiAgICBNZXRlb3IucHVibGlzaChcIkFwcHNoZWV0TGlua1wiLCBmdW5jdGlvbigpe1xuXG4gICAgICAgIHJldHVybiBBcHBzaGVldExpbmsuZmluZCgpO1xuICAgIH0pO1xuICAgIH0pO1xufVxuXG4gICJdfQ==
